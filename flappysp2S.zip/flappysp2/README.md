FlappyCoin 
================================
Current version: 3.2.1

Copyright (c) 2017 Bitcoin Developers

Copyright (c) 2017 FlappyCoin Developers


Specifications:
---------------
Algorithm: Scrypt

Block Time: 60 Seconds

Difficulty Retarget Time: 1 minutes (with KGW)

Premine: None



# flappysp1
# flappysp1
